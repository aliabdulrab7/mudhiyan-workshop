# Phase 1 — Token swap (5 minutes)

Two files to replace in your `client/` codebase. Everything is backward-compatible: all your legacy class names (`--gold`, `btn-gold`, `--text-primary`, `ink.*`, `bg.primary`) still resolve to the new token values. Nothing should break.

## Step 1 — Replace `client/src/index.css`

Open `migration/index.css` in this project and paste its contents over your current `client/src/index.css`. The file keeps your mobile bottom-tab-bar, skeleton shimmer, and all your other utilities untouched — only the `:root` tokens, scrollbar, and button/input base classes are modernized.

## Step 2 — Replace `client/tailwind.config.js`

Same deal: paste `migration/tailwind.config.js` over your current file.

## Step 3 — Add JetBrains Mono to `client/index.html`

Find the Google Fonts `<link>` tag and replace the `href` with:

```html
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

If you don't already have a fonts link, add the `<link>` above inside `<head>`.

## Step 4 — Run

```bash
cd client
npm run dev
```

Everything should look **almost identical** — slightly tighter borders, slightly warmer background. No regressions expected.

## Step 5 — Start using `.mono` on numbers

The single biggest readability win. Anywhere you render a number, price, date, ID, or count, add the `mono` class:

```jsx
<span className="font-mono">WB-2055</span>   {/* tailwind */}
<span className="mono">180 ر.س</span>         {/* css class */}
<span className="mono">22 أبريل</span>
```

Both `font-mono` (Tailwind) and `.mono` (CSS utility) work — they point to the same font stack with `tabular-nums` enabled.

---

## If something breaks

Most likely culprit: a page using a Tailwind color you removed. Grep for:

```bash
grep -rE "gold-|bg-primary\b|text-primary\b|ink-" client/src
```

The legacy aliases (`bg.primary`, `ink.*`) are still there for compat, but if you had weird ones like `bg-bg-primary` they may need to become `bg-bg` (default) or `bg-bg-soft`.

Revert anytime: `git checkout client/src/index.css client/tailwind.config.js`.
