# Full Migration Guide — Workbench Prototype → `client/` Codebase

> **Audience:** Claude (or any engineer) executing the migration end-to-end.
> **Source of truth:** This project — a design prototype at the repo root.
> **Target:** The real production app in `client/` (Vite + React 19 + Tailwind + react-router-dom).
> **Outcome:** Target app adopts the prototype's visual system, primitives, and new features (⌘K command palette, refined Track page, dashboard cockpit, multi-step intake, toast system), without breaking auth, routing, API calls, or existing business logic.

---

## Ground Rules

1. **Never file-swap.** The prototype uses inline Babel + window globals + mock data. The target uses ES modules + react-router + real APIs. Every port is a **rewrite**, not a copy.
2. **Work in phases, commit at each phase boundary.** Each phase produces a running app. If you break one, `git checkout` back to the last phase.
3. **Preserve all existing behavior** — auth guards (`PrivateRoute`, `RoleRoute`), routes, API contracts, localStorage usage, WhatsApp links, barcode/label printing (`niimbluelib`, `jsbarcode`, `html5-qrcode`), Arabic-only UX. None of these should change.
4. **RTL stays RTL.** The prototype has a `lang` prop for bilingual mode — **drop it entirely** in the target. The target is Arabic-only. Remove all `lang === 'ar' ? … : …` ternaries; keep only the Arabic branch.
5. **Tailwind-first.** Replace inline `style={{…}}` objects with Tailwind utility classes wherever practical. Exceptions: dynamic color interpolation, SVG attributes, animation keyframes.
6. **One PR per phase.** Phase 1, 2, 3.1, 3.2, 3.3, 3.4, 3.5, 4. Eight small PRs > one giant one.
7. **No new dependencies without asking.** The target already has framer-motion, niimbluelib, jsbarcode, html5-qrcode, qrcode, react-router-dom. That's enough.

---

## Repo Map

**Prototype (this project, read-only reference):**

```
src/
  app.jsx              ← App shell: sidebar + topbar + page switcher
  data.jsx             ← I18N, STATUS_META, MOCK_ORDERS, SERVICES, etc.
  icons.jsx            ← Inline SVG icon set (Dashboard, Orders, Scan, …)
  primitives.jsx       ← StatusPill, Checkbox, Avatar, Kbd, PriorityDot, Sparkline
  palette.jsx          ← ⌘K command palette
  sidebar.jsx          ← Sidebar nav
  topbar.jsx           ← Top search bar + actions
  page_dashboard.jsx   ← Cockpit: stats row, needs attention, activity
  page_orders.jsx      ← Dense orders table (DataTable pattern)
  page_new.jsx         ← Multi-step intake
  page_detail.jsx      ← Order detail drawer/page
  page_track.jsx       ← Public customer tracking page
  page_label.jsx       ← Label print
  page_scan.jsx        ← Scan screen
  tweaks.jsx           ← Prototype-only tweaks panel — DO NOT MIGRATE
styles.css             ← Design tokens + component classes
index.html             ← Prototype shell (not used)
```

**Target (`client/`, production):**

```
client/
  src/
    App.jsx                         ← BrowserRouter + route table (keep)
    main.jsx                        ← Entry (keep)
    index.css                       ← Tokens + component classes (Phase 1 replaces this)
    api/
      auth.js, orders.js, …         ← Real API client (DO NOT TOUCH)
    hooks/
      useApprovalNotifications.js   ← Keep
    components/
      Layout.jsx                    ← Sidebar + main + bottom tab bar
      OrderList.jsx                 ← Current orders table — Phase 2 replaces
      OrderForm.jsx                 ← Current intake — Phase 3.4 replaces
      OrderDetail.jsx               ← Current detail — keep, minor polish
      StatusBadge.jsx               ← Current badge — Phase 2 replaces with StatusPill
      Toast.jsx                     ← Keep, Phase 3.5 wires up more triggers
      BarcodeScanner.jsx            ← Keep (html5-qrcode)
      LabelCanvas.jsx               ← Keep (jsbarcode)
      ReadyLabelCanvas.jsx          ← Keep
      useLabelPrint.js              ← Keep (niimbluelib)
      PrivateRoute.jsx, RoleRoute.jsx, SkeletonLoader.jsx, CostEditor.jsx, ScanResult.jsx  ← Keep
    pages/
      Dashboard.jsx                 ← Phase 3.3 replaces
      NewOrder.jsx                  ← Phase 3.4 replaces
      TrackPage.jsx                 ← Phase 3.2 replaces
      ScanPage.jsx, LoginPage.jsx, LabelPrintPage.jsx  ← Keep
      BranchesPage.jsx, ReportsPage.jsx, TechniciansPage.jsx, InventoryPage.jsx, ServicesPage.jsx  ← Keep
  tailwind.config.js   ← Phase 1 replaces
  index.html           ← Phase 1 updates fonts link
  package.json         ← No changes
```

---

## Phase 1 — Design Tokens (5 min, ZERO risk)

**Status:** Already prepared in this project. User may have already done this. Verify before proceeding.

### Files to replace

| Source (this project) | Destination |
|---|---|
| `migration/index.css`        | `client/src/index.css` |
| `migration/tailwind.config.js` | `client/tailwind.config.js` |

### Changes in `client/index.html`

Replace the Google Fonts `<link>` with:

```html
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

### Verify

```bash
cd client && npm run dev
```

App should look near-identical. Slightly warmer `#F7F8FA` background, tighter 6px radii. **Commit: "feat: adopt Workbench design tokens (Phase 1)".**

### Rule introduced

From this point forward, every **number, price, date, ID, or count** gets `className="font-mono"` (or `className="mono"`). This is the single biggest readability win.

---

## Phase 2 — Shared Primitives (1.5–2 hrs)

Build three primitive components, then find/replace ad-hoc uses across the codebase.

### 2.1 `components/StatusPill.jsx` (replaces `StatusBadge.jsx`)

**Reference:** `src/primitives.jsx` → `StatusPill`, `src/data.jsx` → `STATUS_META`.

**Port:**

```jsx
// client/src/components/StatusPill.jsx
const STATUS_META = {
  received:         { color: '#2980B9', label: 'مستلمة' },
  inspection:       { color: '#92400E', label: 'قيد الفحص' },
  waiting_approval: { color: '#B45309', label: 'بانتظار الموافقة' },
  in_repair:        { color: '#1E40AF', label: 'قيد الإصلاح' },
  quality_check:    { color: '#6B21A8', label: 'فحص الجودة' },
  ready_for_return: { color: '#166534', label: 'جاهزة' },
  delivered:        { color: '#374151', label: 'تم التسليم' },
  // include any legacy statuses your API returns
};

export default function StatusPill({ status, size = 'md' }) {
  const meta = STATUS_META[status] || STATUS_META.received;
  const pad = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border ${pad} font-medium`}
      style={{
        color: meta.color,
        borderColor: `color-mix(in oklch, ${meta.color} 30%, var(--border))`,
        background: `color-mix(in oklch, ${meta.color} 9%, var(--bg-raised))`,
      }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: meta.color }} />
      {meta.label}
    </span>
  );
}
```

**Find/replace:** grep for `StatusBadge` across `client/src`, swap to `StatusPill`. Check the `status` prop name still works — if the old API used a different key (e.g. `state`), normalize at the component boundary.

**Delete:** `components/StatusBadge.jsx` after all usages are swapped.

### 2.2 `components/Button.jsx`

Three variants (`primary`, `ghost`, `subtle`), three sizes (`sm`, `md`, `lg`). Use Tailwind for everything.

```jsx
// client/src/components/Button.jsx
const variants = {
  primary: 'bg-primary text-white border-primary-hover hover:bg-primary-hover hover:shadow-[0_0_0_3px_var(--primary-ring)]',
  ghost:   'bg-bg-raised text-text-soft border-border hover:border-primary hover:text-primary hover:bg-primary-soft',
  subtle:  'bg-transparent text-text-muted border-transparent hover:bg-bg-soft hover:text-text',
};
const sizes = {
  sm: 'text-xs px-2.5 py-1 gap-1',
  md: 'text-sm px-4 py-2 gap-1.5',
  lg: 'text-[15px] px-5 py-2.5 gap-2',
};
export default function Button({ variant = 'ghost', size = 'md', icon, children, className = '', ...rest }) {
  return (
    <button
      className={`inline-flex items-center justify-center rounded border font-medium transition-all disabled:opacity-40 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]} ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}
```

**Find/replace:** grep `btn-gold`, `btn-ghost`, `btn-primary`, `btn-ghost-sm` across `client/src`. Each usage → `<Button variant="primary|ghost|subtle" size="sm|md|lg" />`. Keep the CSS classes around (they're in `index.css`) as a fallback during the transition, but aim to eliminate them.

### 2.3 `components/DataTable.jsx`

**Reference:** `src/page_orders.jsx` (the whole table).

The patterns to preserve from the prototype:
- **40px row height** — dense but breathable
- **Right-border accent** on hover (RTL-correct)
- **Checkbox column** on the start side for bulk select
- **Column alignment:** text start, numbers end, status centered
- **Zebra striping is optional** — prefer hover-only
- **Sticky header** with muted 11px uppercase labels

```jsx
// client/src/components/DataTable.jsx
export default function DataTable({ columns, rows, selected, onSelect, getRowKey, onRowClick }) {
  const allSelected = selected?.size === rows.length && rows.length > 0;
  const someSelected = selected?.size > 0 && !allSelected;

  return (
    <div className="bg-bg-raised border border-border rounded overflow-hidden">
      <table className="w-full border-collapse">
        <thead className="bg-bg-soft border-b border-border">
          <tr>
            {onSelect && (
              <th className="w-9 p-2 text-start">
                <Checkbox
                  checked={allSelected}
                  indeterminate={someSelected}
                  onChange={v => onSelect(v ? new Set(rows.map(getRowKey)) : new Set())}
                />
              </th>
            )}
            {columns.map(col => (
              <th
                key={col.key}
                className={`px-3 py-2 text-[11px] uppercase tracking-wider text-text-muted font-medium text-${col.align || 'start'}`}
                style={{ width: col.width }}
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => {
            const key = getRowKey(row);
            const isSel = selected?.has(key);
            return (
              <tr
                key={key}
                className={`order-row border-b border-border-faint last:border-0 ${isSel ? 'bg-primary-soft' : ''} hover:cursor-pointer`}
                onClick={() => onRowClick?.(row)}
              >
                {onSelect && (
                  <td className="p-2" onClick={e => e.stopPropagation()}>
                    <Checkbox
                      checked={isSel}
                      onChange={v => {
                        const next = new Set(selected);
                        v ? next.add(key) : next.delete(key);
                        onSelect(next);
                      }}
                    />
                  </td>
                )}
                {columns.map(col => (
                  <td
                    key={col.key}
                    className={`px-3 py-2.5 text-sm text-${col.align || 'start'} ${col.mono ? 'font-mono tabular-nums' : ''}`}
                  >
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
```

Also port `Checkbox` from `src/primitives.jsx` into `components/Checkbox.jsx` (trivial — it's 15 lines).

**Find/replace:** Rewrite `components/OrderList.jsx` to use `DataTable` with a columns array. Before/after ratio: usually ~200 lines → ~60 lines.

### Phase 2 verify

```bash
npm run dev
# Click through every page that uses status badges or the orders table
# Verify bulk-select works, row hover shows right-border accent
# Verify buttons look consistent across Dashboard, NewOrder, OrderDetail
```

**Commit: "feat: StatusPill + Button + DataTable primitives (Phase 2)".**

---

## Phase 3 — Port the New Features

Do these in dependency order. Each has its own verify step and commit.

### 3.1 ⌘K Command Palette (45 min — HIGHEST ROI)

**Reference:** `src/palette.jsx`, `src/icons.jsx`.

**Port as:** `client/src/components/CommandPalette.jsx`.

**Adapt for target:**

```jsx
// client/src/components/CommandPalette.jsx
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getRole } from '../api/auth';
// (optional) import { listOrders } from '../api/orders';

export default function CommandPalette({ open, onClose, orders = [] }) {
  const navigate = useNavigate();
  const role = getRole();
  const [q, setQ] = useState('');
  const [focus, setFocus] = useState(0);
  const inputRef = useRef(null);

  const go = (path) => { navigate(path); onClose(); };

  const commands = useMemo(() => {
    const workshopOnly = role === 'workshop';
    return [
      { group: 'انتقال', items: [
        { id: 'go:home',   label: 'الطلبات',         hint: 'G D', fn: () => go('/') },
        { id: 'go:new',    label: 'صيانة جديدة',      hint: 'N',   fn: () => go('/new') },
        { id: 'go:scan',   label: 'مسح',             hint: 'G S', fn: () => go('/scan') },
        workshopOnly && { id: 'go:branches',    label: 'الفروع',   fn: () => go('/branches') },
        workshopOnly && { id: 'go:reports',     label: 'التقارير', fn: () => go('/reports') },
        workshopOnly && { id: 'go:technicians', label: 'الفنيون',  fn: () => go('/technicians') },
        workshopOnly && { id: 'go:inventory',   label: 'المخزون',  fn: () => go('/inventory') },
        workshopOnly && { id: 'go:services',    label: 'الخدمات',  fn: () => go('/services') },
      ].filter(Boolean) },
      { group: 'الطلبات', items: orders.slice(0, 8).map(o => ({
        id: 'ord:' + o.id,
        label: `${o.order_number} — ${o.customer_name}`,
        hint: o.piece_type,
        fn: () => go(`/?order=${o.id}`),  // or however you open detail
      }))},
    ];
  }, [orders, role]);

  const flat = commands.flatMap(g => g.items.map(it => ({ ...it, group: g.group })));
  const filtered = q
    ? flat.filter(it => it.label.toLowerCase().includes(q.toLowerCase()))
    : flat;

  const groups = filtered.reduce((acc, it) => {
    (acc[it.group] = acc[it.group] || []).push(it);
    return acc;
  }, {});

  useEffect(() => {
    if (open) { inputRef.current?.focus(); setQ(''); setFocus(0); }
  }, [open]);
  useEffect(() => { setFocus(0); }, [q]);

  function onKey(e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); setFocus(f => Math.min(filtered.length - 1, f + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setFocus(f => Math.max(0, f - 1)); }
    else if (e.key === 'Enter')   { e.preventDefault(); filtered[focus]?.fn(); }
    else if (e.key === 'Escape')  { onClose(); }
  }

  if (!open) return null;

  let idx = -1;
  return (
    <div
      className="fixed inset-0 z-[300] bg-black/30 backdrop-blur-sm flex items-start justify-center pt-[15vh]"
      onClick={onClose}
    >
      <div
        className="w-[90vw] max-w-[560px] bg-bg-raised border border-border rounded-lg shadow-lg overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <input
          ref={inputRef}
          className="w-full px-4 py-3.5 text-[15px] border-0 border-b border-border outline-none bg-transparent"
          placeholder="اكتب للبحث أو التنقل…"
          value={q}
          onChange={e => setQ(e.target.value)}
          onKeyDown={onKey}
        />
        <div className="max-h-[55vh] overflow-y-auto">
          {Object.keys(groups).length === 0 && (
            <div className="px-4 py-5 text-center text-sm text-text-muted">لا توجد نتائج</div>
          )}
          {Object.entries(groups).map(([g, items]) => (
            <div key={g}>
              <div className="px-4 pt-2.5 pb-1 text-[10px] uppercase tracking-wider text-text-faint">{g}</div>
              {items.map(it => {
                idx += 1;
                const isFocus = idx === focus;
                return (
                  <div
                    key={it.id}
                    className={`flex items-center gap-3 px-4 py-2.5 cursor-pointer text-sm ${isFocus ? 'bg-primary-soft text-primary' : 'text-text'}`}
                    onClick={it.fn}
                    onMouseEnter={() => setFocus(flat.findIndex(x => x.id === it.id))}
                  >
                    <span className="flex-1">{it.label}</span>
                    {it.hint && <kbd className="text-[10px] font-mono px-1.5 py-0.5 bg-bg-soft border border-border rounded">{it.hint}</kbd>}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        <div className="flex gap-3 px-4 py-2 border-t border-border text-[11px] text-text-faint">
          <span>↑↓ تنقل</span>
          <span>↵ اختيار</span>
          <span>esc إغلاق</span>
        </div>
      </div>
    </div>
  );
}
```

**Mount globally** in `components/Layout.jsx`:

```jsx
import { useEffect, useState } from 'react';
import CommandPalette from './CommandPalette';
// …
export default function Layout({ children }) {
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [orders, setOrders] = useState([]);

  // Load a lightweight orders list for palette search (cache-friendly)
  useEffect(() => {
    let cancelled = false;
    import('../api/orders').then(({ listOrders }) =>
      listOrders?.().then(data => !cancelled && setOrders(data || []))
    ).catch(() => {});
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen(v => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="main-layout" /* … */>
      {/* existing sidebar + main + bottom tab bar */}
      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} orders={orders} />
    </div>
  );
}
```

**Also add** a visible "⌘K" hint button in the sidebar header that calls `setPaletteOpen(true)` — users need to discover it.

**Verify:** Press ⌘K (Cmd on Mac, Ctrl on Windows) from any page. Palette opens, focuses input. Type "مسح" → "مسح" highlights. Enter navigates to `/scan`. Esc closes. Type an order number → jumps to detail.

**Commit: "feat: ⌘K command palette (Phase 3.1)".**

---

### 3.2 Track Page Redesign (30 min)

**Reference:** `src/page_track.jsx`.

**Replace:** `client/src/pages/TrackPage.jsx`.

**Key things to port:**
- Centered single-card layout, no sidebar (it's already route-public)
- 6-stage horizontal timeline: `received → inspection → in_repair → quality_check → ready_for_return → delivered`
- **RTL label fix** (important, user reported this): `بدأ` on the START side of the timeline (right edge in RTL), `متوقّع الوصول للفرع: <date>` on the END side (left edge in RTL)
- Each stage: 20px circle, primary fill if done, primary border with 4px ring if current, border-strong if future. Checkmark SVG in done, dot in current, empty in future.
- Two info tiles (drop-off location + estimated total)
- Two CTAs (contact branch, approve quote)
- Auto-updates tagline at bottom: "يُحدَّث تلقائيًا · لا يتطلب إنشاء حساب"

**Adapt for target:**
- Use `useParams()` to get the tracking `token`
- Fetch order via your existing `api/orders.js` — look up by tracking token, not by ID
- Remove `lang` prop entirely; all labels Arabic
- Use Tailwind utility classes instead of inline styles
- Use your existing `StatusPill` from Phase 2

**Verify:** Visit `/track/<someToken>` with a real order. Timeline stages reflect actual order status. RTL labels positioned correctly (see screenshot comparison in `screenshots/track-fixed2.png` of this project).

**Commit: "feat: refined public TrackPage (Phase 3.2)".**

---

### 3.3 Dashboard Cockpit (1 hr)

**Reference:** `src/page_dashboard.jsx`.

**Replace:** `client/src/pages/Dashboard.jsx`.

**Structure (top to bottom):**

1. **Header row** — page title + right-aligned actions (Export, Refresh)
2. **Stats row** — 5 cards, equal width, grid:
   - Received today
   - In repair
   - Waiting approval  *(clickable filter)*
   - Ready for pickup  *(clickable filter)*
   - Overdue  *(clickable filter, red accent if >0)*

   Each card: 11px uppercase label · **big mono number** (28–32px, 600 weight) · optional delta vs yesterday · optional sparkline.

3. **Main 2-column grid:**
   - **Left (2/3 width):** "تحتاج انتباهك" (Needs your attention) — list of flagged orders: overdue, pending customer approval >48h, out-of-stock parts. Each row: order number · customer · issue · status pill · action button.
   - **Right (1/3 width):** "آخر النشاط" (Recent activity) — feed of recent events: "تم استلام طلب جديد", "وافق العميل على التسعير"… time-ago on each.

4. **Recent orders** — dense 10-row `DataTable` at the bottom (use primitive from Phase 2), click → order detail.

**Data sources:** use your existing `api/orders.js`, `api/admin.js`. Compute the "needs attention" list client-side by filtering orders with `status === 'waiting_approval' && daysOld > 2` etc.

**Remove:** any decorative hero art, gradients, or floating icons. Cockpit = information density.

**Verify:** Dashboard loads in <500ms, all numbers render in mono, clicking a stat card filters the orders list, clicking a "needs attention" row opens detail.

**Commit: "feat: Dashboard cockpit (Phase 3.3)".**

---

### 3.4 Multi-Step New Order Intake (1.5 hr)

**Reference:** `src/page_new.jsx`, `src/data.jsx` (SERVICES, PIECE_TYPES).

**Replace:** `client/src/pages/NewOrder.jsx` (which currently uses `components/OrderForm.jsx`).

**4-step wizard:**

1. **Customer** — search existing customers (typeahead on phone/name) OR create new (name, phone, WhatsApp opt-in)
2. **Pieces & issues** — add multiple pieces with: type (dropdown), description, issue (dropdown), photos (upload, optional)
3. **Services & pricing** — per-piece service selection, auto-totaled at bottom, editable unit prices
4. **Review** — full summary card, submit button

**Shared UX:**
- Step indicator at top (4 dots)
- Prev/Next at bottom (Prev hidden on step 1, Next renamed "إنشاء الطلب" on step 4)
- **Keyboard:** Tab flows through fields, Enter advances step, Cmd+Enter submits from anywhere
- **Validation:** each step blocks Next until required fields filled; inline errors under each input
- State lives in `useState` object, persists to `sessionStorage` so refresh doesn't lose input

**API:** on step 4 submit, call your existing `api/orders.js` → `createOrder(payload)`. Payload shape must match whatever your backend expects today — don't change the contract.

**Verify:** Walk through all 4 steps. Create a real order. Check it appears in the orders list. Refresh mid-flow — state should restore.

**Commit: "feat: multi-step intake wizard (Phase 3.4)".**

---

### 3.5 Toast System Expansion (20 min)

**Reference:** `src/app.jsx` → toast usage patterns.

Your `components/Toast.jsx` already exists. The job here is **wire up more triggers** and standardize the format.

**Conventions to adopt:**
- Top-center position, auto-dismiss after 4s
- Three variants: `success` (green check), `info` (blue), `error` (red) — use the `status-*` tokens
- Fire toasts from:
  - Order created → "تم إنشاء الطلب WB-2055"
  - Status changed → "قيد الإصلاح الآن"
  - Customer approved quote → "وافق العميل على تسعير WB-2055"
  - Label printed → "تمت الطباعة"
  - Barcode scan success / failure
  - Approval notification arriving (via `useApprovalNotifications`)

If you don't have a global toast context, add one:

```jsx
// client/src/components/ToastProvider.jsx
import { createContext, useContext, useState, useCallback } from 'react';
const Ctx = createContext(null);
export function useToast() { return useContext(Ctx); }
export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const push = useCallback((text, variant = 'info') => {
    const id = Math.random().toString(36).slice(2);
    setToasts(t => [...t, { id, text, variant }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4000);
  }, []);
  return (
    <Ctx.Provider value={push}>
      {children}
      <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[400] flex flex-col gap-2 items-center">
        {toasts.map(t => <Toast key={t.id} {...t} />)}
      </div>
    </Ctx.Provider>
  );
}
```

Wrap `<App />` in `main.jsx`. Usage: `const toast = useToast(); toast('تم الحفظ', 'success');`.

**Commit: "feat: unified toast system (Phase 3.5)".**

---

## Phase 4 — Polish Pass (1 hr)

Walk every page (Dashboard, Orders, NewOrder, OrderDetail, Scan, LabelPrint, Track, Branches, Reports, Technicians, Inventory, Services, Login) and apply:

### 4.1 Tabular numerals everywhere

grep for any `<span>`, `<td>`, `<div>` rendering a number, date, price, ID, percent, count, duration:

```bash
cd client
grep -rE '>\s*\{.*\.(price|amount|total|count|id|number|created_at|updated_at|eta)' src
```

Add `className="font-mono"` or wrap in `<span className="font-mono">`.

### 4.2 Tighten spacing

Default gap between cards: **12px** (not 16). Default card padding: **16px** (not 24). Use Tailwind `gap-3`, `p-4` — not `gap-4`, `p-6`.

### 4.3 Status pill, never text

Grep for any place rendering `order.status` as plain text. Replace with `<StatusPill status={order.status} />`.

```bash
grep -rE '\{.*\.status\}' client/src/components client/src/pages | grep -v StatusPill
```

### 4.4 Remove decorative gradients & ornaments

- Sidebar logo `linear-gradient(135deg, #2980B9, #1A6EA0)` → flat `bg-primary`
- Any `background: linear-gradient(…)` in page headers → flat `bg-bg-raised`
- `◈ ✦ ⌖ ⊛` decorative unicode glyphs in the sidebar nav → use simple SVG icons from `src/icons.jsx` (copy icons over as `components/icons.jsx`)

### 4.5 Consistent empty states

Every list/table needs an empty state:
- small SVG icon (muted)
- one-line description ("لا توجد طلبات بعد")
- one CTA button ("إنشاء طلب جديد")

### 4.6 Remove dead CSS

After Phase 2, delete from `index.css` anything no longer used:
- `.btn-gold`, `.btn-ghost`, `.btn-primary` class blocks (Button component replaces)
- Old status color classes if StatusPill handles all

Keep mobile media queries, skeleton, animations.

**Commit: "chore: polish pass — tabular nums, status pills, spacing (Phase 4)".**

---

## What to NOT Migrate

- **`src/tweaks.jsx`** — prototype-only tweaks panel.
- **`src/data.jsx`** — mock data; the target uses real APIs.
- **The bilingual toggle** — target is Arabic-only. Drop every `lang === 'ar' ? x : y` and keep only `x`.
- **Fake "Export / Refresh" buttons** — prototype has them as mock; target should only show them if they do something real.
- **`deck_stage.js`, animation starters** — not applicable.
- **The "back to app" button** on the prototype's Track page — that's a prototype nav affordance; remove it in the target.

---

## Acceptance Checklist (before calling migration done)

- [ ] `npm run dev` runs with zero console errors
- [ ] `npm run build` succeeds
- [ ] `npm run lint` passes
- [ ] Login still works (auth unchanged)
- [ ] Dashboard loads, stat cards clickable, numbers all mono
- [ ] Orders table: hover shows right-border accent, bulk-select works, status pills render
- [ ] ⌘K opens palette from any page, keyboard-navigable, closes on Esc
- [ ] New order flow: 4 steps, validation works, creates order via real API
- [ ] Track page (`/track/:token`): RTL timeline correct (`بدأ` on right), ETA on left
- [ ] Label print still works (niimbluelib)
- [ ] Barcode scan still works (html5-qrcode)
- [ ] Mobile: bottom tab bar still visible, FAB works, responsive
- [ ] Tabular numerals on EVERY number in the app
- [ ] Zero `{order.status}` raw text renders anywhere
- [ ] WhatsApp approval links still format correctly
- [ ] All existing routes still accessible under same URLs

---

## Estimated Total Time

| Phase | Time |
|---|---|
| 1 — Tokens | 5 min |
| 2 — Primitives | 1.5–2 hr |
| 3.1 — ⌘K Palette | 45 min |
| 3.2 — TrackPage | 30 min |
| 3.3 — Dashboard | 1 hr |
| 3.4 — NewOrder | 1.5 hr |
| 3.5 — Toasts | 20 min |
| 4 — Polish | 1 hr |
| **Total** | **~6–7 hrs** |

Can be done in a single focused day, or spread over 3 PRs across a week.

---

## If You Get Stuck

- The prototype is always readable reference. Read `src/page_*.jsx` for the canonical layout.
- The prototype's `styles.css` shows the full design-token intent — any token you're unsure about, check there.
- All prototype files are cross-project readable at `/projects/<this-project-id>/src/*`.
- When in doubt: keep the existing behavior, change only the visual layer. Business logic, API contracts, auth, and print integrations stay untouched.
