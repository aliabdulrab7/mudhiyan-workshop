# Phase 2 — Shared Primitives

**Time:** 1.5–2 hours
**Risk:** Medium (you're replacing components used across many pages)
**Goal:** Stop defining ad-hoc buttons, badges, and tables. Three new primitives replace them all.

---

## Prereq

Phase 1 done (new tokens + Tailwind config in place).

## Files created

- `client/src/components/StatusPill.jsx`
- `client/src/components/Button.jsx`
- `client/src/components/Checkbox.jsx`
- `client/src/components/DataTable.jsx`

## Files deleted (at end of phase)

- `client/src/components/StatusBadge.jsx` (replaced by StatusPill)

## Files edited

- Every page and component that used `StatusBadge`, `btn-gold`, `btn-ghost`, `btn-primary`, or `components/OrderList.jsx`.

---

## Step 1 — Create `StatusPill.jsx`

Path: `client/src/components/StatusPill.jsx`

```jsx
const STATUS_META = {
  received:         { color: '#2980B9', label: 'مستلمة' },
  inspection:       { color: '#92400E', label: 'قيد الفحص' },
  waiting_approval: { color: '#B45309', label: 'بانتظار الموافقة' },
  in_repair:        { color: '#1E40AF', label: 'قيد الإصلاح' },
  quality_check:    { color: '#6B21A8', label: 'فحص الجودة' },
  ready_for_return: { color: '#166534', label: 'جاهزة' },
  delivered:        { color: '#374151', label: 'تم التسليم' },
  // Add any other status strings your API returns here.
};

export default function StatusPill({ status, size = 'md' }) {
  const meta = STATUS_META[status] || STATUS_META.received;
  const pad = size === 'sm' ? 'px-2 py-0.5 text-[11px]' : 'px-2.5 py-1 text-xs';
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border font-medium ${pad}`}
      style={{
        color: meta.color,
        borderColor: `color-mix(in oklch, ${meta.color} 30%, var(--border))`,
        background: `color-mix(in oklch, ${meta.color} 9%, var(--bg-raised))`,
      }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: meta.color }} />
      {meta.label}
    </span>
  );
}

export { STATUS_META };
```

## Step 2 — Create `Checkbox.jsx`

Path: `client/src/components/Checkbox.jsx`

```jsx
export default function Checkbox({ checked, indeterminate, onChange }) {
  return (
    <span
      role="checkbox"
      aria-checked={checked}
      onClick={(e) => { e.stopPropagation(); onChange?.(!checked); }}
      className={`inline-grid place-items-center w-4 h-4 rounded-sm border cursor-pointer transition-colors
        ${checked || indeterminate ? 'bg-primary border-primary' : 'bg-bg-raised border-border-strong hover:border-primary'}`}
    >
      {checked && !indeterminate && (
        <svg viewBox="0 0 12 12" className="w-3 h-3"><polyline points="2.5,6.5 5,9 9.5,3.5" fill="none" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/></svg>
      )}
      {indeterminate && (
        <svg viewBox="0 0 12 12" className="w-3 h-3"><line x1="3" y1="6" x2="9" y2="6" stroke="#fff" strokeWidth="2" strokeLinecap="round"/></svg>
      )}
    </span>
  );
}
```

## Step 3 — Create `Button.jsx`

Path: `client/src/components/Button.jsx`

```jsx
const VARIANTS = {
  primary: 'bg-primary text-white border-primary-hover hover:bg-primary-hover focus-visible:ring-2 focus-visible:ring-primary-ring',
  ghost:   'bg-bg-raised text-text-soft border-border hover:border-primary hover:text-primary hover:bg-primary-soft',
  subtle:  'bg-transparent text-text-muted border-transparent hover:bg-bg-soft hover:text-text',
  danger:  'bg-bg-raised text-red-600 border-border hover:border-red-400 hover:bg-red-50',
};
const SIZES = {
  sm: 'text-xs px-2.5 py-1 gap-1 rounded-sm',
  md: 'text-sm px-4 py-2 gap-1.5 rounded',
  lg: 'text-[15px] px-5 py-2.5 gap-2 rounded',
};

export default function Button({
  variant = 'ghost',
  size = 'md',
  icon,
  children,
  className = '',
  type = 'button',
  ...rest
}) {
  return (
    <button
      type={type}
      className={`inline-flex items-center justify-center border font-medium transition-all outline-none
        disabled:opacity-40 disabled:cursor-not-allowed
        ${VARIANTS[variant]} ${SIZES[size]} ${className}`}
      {...rest}
    >
      {icon}
      {children}
    </button>
  );
}
```

## Step 4 — Create `DataTable.jsx`

Path: `client/src/components/DataTable.jsx`

```jsx
import Checkbox from './Checkbox';

/**
 * Columns: [{ key, label, width?, align?, mono?, render?(row) }]
 * selected: Set<string>
 * onSelect: (Set<string>) => void
 * getRowKey: (row) => string
 * onRowClick: (row) => void
 */
export default function DataTable({
  columns, rows, selected, onSelect, getRowKey, onRowClick, emptyState,
}) {
  if (rows.length === 0 && emptyState) return emptyState;

  const keys = rows.map(getRowKey);
  const allSelected = selected && selected.size === rows.length && rows.length > 0;
  const someSelected = selected && selected.size > 0 && !allSelected;

  return (
    <div className="bg-bg-raised border border-border rounded overflow-hidden">
      <table className="w-full border-collapse">
        <thead className="bg-bg-soft border-b border-border sticky top-0">
          <tr>
            {onSelect && (
              <th className="w-10 p-2 text-start">
                <Checkbox
                  checked={allSelected}
                  indeterminate={someSelected}
                  onChange={(v) => onSelect(v ? new Set(keys) : new Set())}
                />
              </th>
            )}
            {columns.map((col) => (
              <th
                key={col.key}
                className={`px-3 py-2 text-[11px] uppercase tracking-wider text-text-muted font-medium
                  ${col.align === 'end' ? 'text-end' : col.align === 'center' ? 'text-center' : 'text-start'}`}
                style={{ width: col.width }}
              >
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => {
            const k = getRowKey(row);
            const isSel = selected?.has(k);
            return (
              <tr
                key={k}
                onClick={() => onRowClick?.(row)}
                className={`order-row border-b border-border-faint last:border-0 cursor-pointer
                  ${isSel ? 'bg-primary-soft' : ''}`}
              >
                {onSelect && (
                  <td className="p-2" onClick={(e) => e.stopPropagation()}>
                    <Checkbox
                      checked={!!isSel}
                      onChange={(v) => {
                        const next = new Set(selected);
                        v ? next.add(k) : next.delete(k);
                        onSelect(next);
                      }}
                    />
                  </td>
                )}
                {columns.map((col) => (
                  <td
                    key={col.key}
                    className={`px-3 py-2.5 text-sm
                      ${col.align === 'end' ? 'text-end' : col.align === 'center' ? 'text-center' : 'text-start'}
                      ${col.mono ? 'font-mono tabular-nums' : ''}`}
                  >
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
```

## Step 5 — Find & replace `StatusBadge`

```bash
cd client
grep -rln 'StatusBadge' src
```

For each match:
1. Change import: `import StatusBadge from …` → `import StatusPill from '../components/StatusPill'`
2. Change JSX: `<StatusBadge status={…} />` → `<StatusPill status={…} />`
3. If props differ (e.g. `type` or `state` instead of `status`), normalize at the call site.

After all replaced, delete `client/src/components/StatusBadge.jsx`.

## Step 6 — Find & replace old button classes

```bash
grep -rlnE 'btn-(gold|ghost|primary|ghost-sm)' client/src
```

For each match:
- `.btn-gold` or `.btn-primary` → `<Button variant="primary">…</Button>`
- `.btn-ghost` → `<Button variant="ghost">…</Button>`
- `.btn-ghost-sm` → `<Button variant="ghost" size="sm">…</Button>`

**Don't delete the CSS classes yet** — leave them in `index.css` as a fallback until you've confirmed every page works. Delete in Phase 4.

## Step 7 — Rewrite `OrderList.jsx` with `DataTable`

Reference: your current `client/src/components/OrderList.jsx` structure.

Skeleton:

```jsx
import DataTable from './DataTable';
import StatusPill from './StatusPill';

export default function OrderList({ orders, selected, setSelected, onOpen }) {
  const columns = [
    { key: 'order_number', label: 'رقم الطلب', width: 120, mono: true },
    { key: 'customer',     label: 'العميل',    render: (o) => o.customer_name },
    { key: 'piece',        label: 'القطعة',    render: (o) => o.piece_type },
    { key: 'issue',        label: 'المشكلة',   render: (o) => o.issue },
    { key: 'status',       label: 'الحالة',    align: 'center',
      render: (o) => <StatusPill status={o.status} size="sm" /> },
    { key: 'created_at',   label: 'التاريخ',   align: 'end', mono: true,
      render: (o) => new Date(o.created_at).toLocaleDateString('ar') },
    { key: 'total',        label: 'الإجمالي', align: 'end', mono: true,
      render: (o) => `${o.total} ر.س` },
  ];

  return (
    <DataTable
      columns={columns}
      rows={orders}
      getRowKey={(o) => o.id}
      selected={selected}
      onSelect={setSelected}
      onRowClick={onOpen}
      emptyState={
        <div className="p-12 text-center text-text-muted text-sm">
          لا توجد طلبات بعد.
        </div>
      }
    />
  );
}
```

Wire `selected` / `setSelected` in the parent (`Dashboard.jsx`) as a `useState(new Set())`.

## Step 8 — Verify

```bash
npm run dev
```

Walk every page with a status badge or orders table:
- [ ] Dashboard orders list renders with new pills
- [ ] Hover a row → right-border accent appears
- [ ] Click checkbox → row highlights; header checkbox toggles all
- [ ] Buttons look consistent (primary blue, ghost with border, all 6px radius)
- [ ] No console errors
- [ ] `npm run build` passes
- [ ] `npm run lint` passes

## Step 9 — Commit

```bash
git add client/src/components client/src/pages
git commit -m "feat: StatusPill + Button + Checkbox + DataTable primitives (Phase 2)"
```

---

## Gotchas

- **Status strings from API:** if your backend returns a status key not in `STATUS_META`, the pill falls back to blue. Add the new key to `STATUS_META`.
- **`mixBlendMode` / `color-mix`:** supported in all modern Chromium/Firefox/Safari. No polyfill needed.
- **Row click vs checkbox click:** `onClick={(e) => e.stopPropagation()}` on the checkbox cell prevents the row click from firing when toggling selection. Don't remove it.
- **Accessibility:** the `Checkbox` uses `role="checkbox"` + `aria-checked`. If you want keyboard support (Space to toggle), add `tabIndex={0}` and a `keyDown` handler.
