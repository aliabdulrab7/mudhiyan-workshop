# Phase 1 — Design Tokens & Mono Font

**Time:** 5 minutes
**Risk:** Zero (all legacy class names still resolve)
**Goal:** Adopt the new color/spacing/radius token system and enable tabular numerals.

---

## Prereq

Target codebase: `client/` with Vite + React 19 + Tailwind + RTL Arabic.

## Files modified

- `client/src/index.css` — full replacement
- `client/tailwind.config.js` — full replacement
- `client/index.html` — fonts `<link>` update

## Files ready to copy

- `migration/index.css` → paste over `client/src/index.css`
- `migration/tailwind.config.js` → paste over `client/tailwind.config.js`

---

## Step 1 — Replace `client/src/index.css`

Open `migration/index.css` in this project. Select all, copy. Paste over the entire contents of `client/src/index.css`. Save.

The file preserves:
- Mobile bottom tab bar + FAB styles
- Skeleton shimmer animation
- Scrollbar styling
- All legacy aliases (`--gold`, `--text-primary`, `btn-gold`, etc.)

The file updates:
- Background: `#F3F4F6` → `#F7F8FA` (slightly warmer)
- Borders: 1 level → 3 levels (`border`, `border-strong`, `border-faint`)
- Text: 3 levels → 4 levels (adds `--text-soft`, `--text-faint`)
- Radius: default 8px → 6px (tighter)
- Shadows: slightly more subtle
- Adds `.mono` utility class for tabular numerals

## Step 2 — Replace `client/tailwind.config.js`

Copy `migration/tailwind.config.js` over `client/tailwind.config.js`. Save.

New scales available:
- `bg.DEFAULT`, `bg.soft`, `bg.raised`, `bg.sidebar`
- `border.DEFAULT`, `border.strong`, `border.faint`
- `text.DEFAULT`, `text.soft`, `text.muted`, `text.faint`
- `primary.DEFAULT`, `primary.hover`, `primary.soft`, `primary.ring`
- `status.received-bg`, `status.received-fg`, … (7 statuses × 2)
- `font-mono` → JetBrains Mono with tabular-nums

Legacy aliases still work: `bg-primary` (old), `ink-primary`, etc.

## Step 3 — Update fonts in `client/index.html`

Find your existing Google Fonts `<link>` and replace with:

```html
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
```

## Step 4 — Smoke test

```bash
cd client
npm run dev
```

Open the app. Walk through Dashboard → Orders → NewOrder → Scan → Login. You should see:
- Slightly warmer background
- Tighter button/card corners (6px not 8px)
- Everything else looks identical

## Step 5 — Verify build & lint

```bash
npm run build
npm run lint
```

Both must pass.

## Step 6 — Commit

```bash
git add client/src/index.css client/tailwind.config.js client/index.html
git commit -m "feat: adopt Workbench design tokens (Phase 1)"
```

---

## What this unlocks

After this phase, you can use `font-mono` (Tailwind) or `className="mono"` (CSS utility) anywhere in the codebase. **Use it on every number from now on.** This is the single biggest readability improvement.

Examples:

```jsx
<span className="font-mono">WB-2055</span>
<span className="font-mono">180 ر.س</span>
<span className="font-mono">22 أبريل</span>
<td className="font-mono tabular-nums">{order.total}</td>
```

Don't do a find/replace for all numbers in this phase — just adopt going forward and clean up in Phase 4.

---

## Rollback

If anything breaks:

```bash
git checkout client/src/index.css client/tailwind.config.js client/index.html
```

## Troubleshooting

**Symptom:** some Tailwind color class stopped working (e.g. `bg-bg-primary`).

**Fix:** the new config exposes `bg.DEFAULT` which you use as `bg-bg`. If you had `bg-bg-primary`, change to `bg-bg` (new neutral bg) or `bg-bg-raised` (white cards). Legacy `bg-primary` still works.

**Symptom:** JetBrains Mono not loading.

**Fix:** check network tab for the fonts.googleapis.com request. If blocked by CSP, add a self-host fallback or check your CSP header.

**Symptom:** all numbers look the same width except when you added `font-mono`.

**Fix:** that's expected — Almarai isn't tabular. That's why we add mono on numbers.
