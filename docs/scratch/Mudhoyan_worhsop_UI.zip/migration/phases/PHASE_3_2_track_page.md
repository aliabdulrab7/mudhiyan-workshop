# Phase 3.2 — Refined Public Track Page

**Time:** 30 min
**Risk:** Low (single public route, unauthenticated users only)
**Goal:** Replace the current `/track/:token` page with the refined customer-facing design. Includes the RTL timeline fix (Started on right, ETA on left).

---

## Prereq

Phase 1 done. Phase 2 done (uses `StatusPill`).

## Files edited

- `client/src/pages/TrackPage.jsx` — full rewrite

---

## Step 1 — Rewrite `TrackPage.jsx`

Path: `client/src/pages/TrackPage.jsx`

```jsx
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import StatusPill from '../components/StatusPill';
// Adapt this import to your actual API:
// e.g. import { getOrderByTrackToken } from '../api/orders';

const STAGES = [
  { key: 'received',         label: 'مستلمة' },
  { key: 'inspection',       label: 'قيد الفحص' },
  { key: 'in_repair',        label: 'قيد الإصلاح' },
  { key: 'quality_check',    label: 'فحص الجودة' },
  { key: 'ready_for_return', label: 'جاهزة' },
  { key: 'delivered',        label: 'تم التسليم' },
];

function formatDate(d) {
  if (!d) return '—';
  return new Date(d).toLocaleDateString('ar', { day: 'numeric', month: 'long' });
}
function formatMoney(n) {
  return `${Number(n || 0).toLocaleString('ar')} ر.س`;
}

export default function TrackPage() {
  const { token } = useParams();
  const [order, setOrder]  = useState(null);
  const [error, setError]  = useState(null);

  useEffect(() => {
    let cancelled = false;
    // Replace with your actual fetcher. Example:
    // getOrderByTrackToken(token).then(…)
    import('../api/orders')
      .then((m) => (m.getOrderByTrackToken || m.getByTrackToken)?.(token))
      .then((data) => !cancelled && setOrder(data))
      .catch((e) => !cancelled && setError(e.message || 'تعذر تحميل الطلب'));
    return () => { cancelled = true; };
  }, [token]);

  if (error) {
    return (
      <div className="min-h-screen grid place-items-center text-text-muted text-sm p-6">
        تعذر العثور على هذا الطلب.
      </div>
    );
  }
  if (!order) {
    return (
      <div className="min-h-screen grid place-items-center text-text-muted text-sm p-6">
        جارِ التحميل…
      </div>
    );
  }

  const currentIdx = STAGES.findIndex((s) => s.key === order.status);
  const first = order.customer_name?.split(' ')[0] || 'عميلنا';
  const total = (order.services || []).reduce((s, x) => s + Number(x.price || 0), 0);

  return (
    <div className="min-h-screen bg-bg px-6 pb-12">
      <div className="max-w-[640px] mx-auto">
        {/* Header */}
        <div className="text-center pt-8 pb-6">
          <div className="inline-flex items-center gap-2.5 mb-5">
            <div className="w-7 h-7 rounded bg-primary grid place-items-center text-white text-sm font-bold">W</div>
            <div className="font-semibold text-sm">ورشة سليمان المضيان</div>
          </div>
          <h1 className="text-[22px] font-semibold tracking-tight m-0">طلبك قيد المتابعة</h1>
          <div className="text-text-muted text-[13px] mt-1.5">
            مرحبًا {first} — إليك حالة طلبك الآن
          </div>
        </div>

        {/* Main card */}
        <div className="bg-bg-raised border border-border rounded-lg p-5 shadow-sm">
          {/* Hero row */}
          <div className="flex items-center gap-3 pb-4 border-b border-border-faint">
            <div className="w-11 h-11 rounded bg-primary grid place-items-center text-white font-mono text-[13px] font-bold">
              {String(order.order_number || '').slice(-3)}
            </div>
            <div className="flex-1">
              <div className="font-semibold text-[15px] font-mono">{order.order_number}</div>
              <div className="text-text-muted text-[12.5px] mt-0.5">
                {order.piece_type} · {order.issue}
              </div>
            </div>
            <StatusPill status={order.status} />
          </div>

          {/* Timeline */}
          <div className="mt-4 bg-bg-soft rounded p-3.5">
            <div dir="rtl" className="flex items-center justify-between text-[11px] text-text-muted uppercase tracking-wider px-1 pb-2">
              <span>بدأ</span>
              <span>
                متوقّع الوصول للفرع:{' '}
                <span className="font-mono text-text">{formatDate(order.eta_at)}</span>
              </span>
            </div>

            <div className="grid grid-cols-6 relative px-1 pt-2">
              {STAGES.map((s, i) => {
                const done = i < currentIdx;
                const cur  = i === currentIdx;
                return (
                  <div key={s.key} className="relative text-center">
                    {i < STAGES.length - 1 && (
                      <div
                        className="absolute top-[9px] h-0.5"
                        style={{
                          left: '50%',
                          right: '-50%',
                          background: done ? 'var(--primary)' : 'var(--border)',
                        }}
                      />
                    )}
                    <div
                      className="w-5 h-5 rounded-full mx-auto mb-2 grid place-items-center relative z-10 text-white text-[10px]"
                      style={{
                        background: done ? 'var(--primary)' : 'var(--bg-raised)',
                        border: `2px solid ${done || cur ? 'var(--primary)' : 'var(--border-strong)'}`,
                        boxShadow: cur ? '0 0 0 4px var(--primary-ring)' : 'none',
                      }}
                    >
                      {done ? '✓' : ''}
                      {cur && <span className="w-2 h-2 rounded-full bg-primary inline-block" />}
                    </div>
                    <div
                      className="text-[10.5px] leading-tight"
                      style={{
                        color: cur ? 'var(--text)' : 'var(--text-muted)',
                        fontWeight: cur ? 600 : 400,
                      }}
                    >
                      {s.label}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Info tiles */}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="bg-bg-soft rounded p-3.5">
              <div className="text-[11px] uppercase tracking-wider text-text-muted mb-1">
                استلام في
              </div>
              <div className="text-[13px] font-medium">{order.branch_name || '—'}</div>
              <div className="font-mono text-[11.5px] text-text-muted mt-0.5">
                {formatDate(order.created_at)}
              </div>
            </div>
            <div className="bg-bg-soft rounded p-3.5">
              <div className="text-[11px] uppercase tracking-wider text-text-muted mb-1">
                القيمة المُقدّرة
              </div>
              <div className="font-mono text-[14px] font-semibold">{formatMoney(total)}</div>
              <div className="text-[11.5px] text-text-muted mt-0.5">
                {(order.services || []).length} خدمة
              </div>
            </div>
          </div>

          {/* CTAs */}
          <div className="mt-5 flex gap-2">
            <a
              href={`https://wa.me/${order.branch_phone || ''}`}
              target="_blank"
              rel="noreferrer"
              className="flex-1 inline-flex items-center justify-center gap-2 bg-primary text-white font-semibold rounded px-4 py-2.5 text-sm hover:bg-primary-hover transition-colors"
            >
              تواصل مع الفرع
            </a>
            <button
              className="flex-1 inline-flex items-center justify-center gap-2 bg-bg-raised border border-border rounded px-4 py-2.5 text-sm hover:border-primary hover:text-primary transition-colors"
              onClick={() => {/* call your approve-quote endpoint */}}
            >
              وافق على التسعير
            </button>
          </div>

          <div className="mt-4 text-[11px] text-text-faint text-center">
            يُحدَّث تلقائيًا · لا يتطلب إنشاء حساب
          </div>
        </div>
      </div>
    </div>
  );
}
```

## Step 2 — Adapt to your API

Critical edits:
- Replace the dynamic import of `../api/orders` with your actual function call.
- Map the fields in the component to the actual keys your API returns:
  - `order_number`, `status`, `piece_type`, `issue`
  - `eta_at`, `created_at`
  - `branch_name`, `branch_phone`
  - `customer_name`
  - `services` array (each with a `price`)

If your field names differ, rename **once at the top** of the component (destructuring) so the JSX stays clean:

```jsx
const {
  number: order_number,
  state: status,
  pieceType: piece_type,
  // …
} = order;
```

## Step 3 — Verify

Visit a real `/track/:token` URL:
- [ ] Page loads with no sidebar (it's a public route — not wrapped in Layout)
- [ ] RTL timeline reads **right-to-left** in stage order
- [ ] "بدأ" label sits on the **right** edge
- [ ] "متوقّع الوصول للفرع: <date>" sits on the **left** edge
- [ ] Current stage has a primary ring around it
- [ ] Completed stages show a ✓
- [ ] Future stages are empty circles with strong-gray borders
- [ ] Two info tiles show drop-off branch + estimated total
- [ ] WhatsApp contact button uses real branch phone
- [ ] Error state shows for bogus tokens
- [ ] `npm run build` passes

## Step 4 — Commit

```bash
git add client/src/pages/TrackPage.jsx
git commit -m "feat: refined public Track page with RTL-correct timeline (Phase 3.2)"
```

---

## Gotchas

- **The connector line direction:** `left: 50%; right: -50%` stretches right-to-left in RTL layout. If your browser quirks display, try swapping to `inset-inline-start: 50%; inset-inline-end: -50%`.
- **`eta_at`:** if your backend doesn't compute an ETA, hide that label cleanly — don't show "Invalid Date".
- **Approve-quote CTA:** wire to your actual approval endpoint and show a toast on success (see Phase 3.5).
- **Public route check:** verify `/track/:token` is OUTSIDE the `PrivateRoute` wrapper in `App.jsx`. It already should be.
