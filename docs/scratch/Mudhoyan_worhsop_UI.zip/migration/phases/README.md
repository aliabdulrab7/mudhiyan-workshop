# Workbench Migration — Phased Guides

Each file in this folder is a self-contained, step-by-step migration phase. Do them in order. Commit between phases. Stop anytime — each phase ships a working app.

## Order

1. **`PHASE_1_tokens.md`** — Design tokens + mono font (5 min, done if you already pasted `migration/index.css`)
2. **`PHASE_2_primitives.md`** — StatusPill, Button, Checkbox, DataTable (1.5–2 hrs)
3. **`PHASE_3_1_command_palette.md`** — ⌘K command palette (45 min)
4. **`PHASE_3_2_track_page.md`** — Refined public Track page (30 min)
5. **`PHASE_3_3_dashboard.md`** — Dashboard cockpit (1 hr)
6. **`PHASE_3_4_new_order.md`** — Multi-step intake wizard (1.5 hrs)
7. **`PHASE_3_5_toasts.md`** — Unified toast system (20 min)
8. **`PHASE_4_polish.md`** — Polish pass (1 hr)

## Rules for every phase

- Arabic-only. Drop every `lang === 'ar' ? x : y`; keep `x`.
- Never change API contracts (`client/src/api/*.js`).
- Never touch `PrivateRoute`, `RoleRoute`, `useLabelPrint`, `BarcodeScanner`, `LabelCanvas`, `ReadyLabelCanvas`.
- Tailwind classes > inline styles. Inline only for dynamic colors / SVG attrs.
- One commit per phase, one PR per phase if possible.
- `npm run dev && npm run build && npm run lint` all pass before committing.

Total: ~6–7 hrs across 8 phases.
