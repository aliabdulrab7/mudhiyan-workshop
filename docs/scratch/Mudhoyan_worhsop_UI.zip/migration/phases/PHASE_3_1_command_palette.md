# Phase 3.1 — ⌘K Command Palette

**Time:** 45 min
**Risk:** Low (isolated new component, doesn't touch existing pages)
**Goal:** Keyboard-first navigation and search from any page. Highest-ROI feature in the migration.

---

## Prereq

Phase 1 done. Phase 2 not strictly required, but recommended.

## Files created

- `client/src/components/CommandPalette.jsx`

## Files edited

- `client/src/components/Layout.jsx` — mount the palette + ⌘K keyboard shortcut

---

## Step 1 — Create `CommandPalette.jsx`

Path: `client/src/components/CommandPalette.jsx`

```jsx
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getRole } from '../api/auth';

export default function CommandPalette({ open, onClose, orders = [] }) {
  const navigate = useNavigate();
  const role = getRole();
  const [q, setQ] = useState('');
  const [focus, setFocus] = useState(0);
  const inputRef = useRef(null);

  const go = (path) => { navigate(path); onClose(); };

  const commands = useMemo(() => {
    const isWorkshop = role === 'workshop';
    const isShop     = role === 'shop_employee';

    return [
      { group: 'انتقال', items: [
        { id: 'go:home', label: 'الطلبات',          hint: 'G D', fn: () => go('/') },
        isShop &&
          { id: 'go:new',  label: 'صيانة جديدة',     hint: 'N',   fn: () => go('/new') },
        { id: 'go:scan', label: 'مسح',              hint: 'G S', fn: () => go('/scan') },
        isWorkshop &&
          { id: 'go:branches',    label: 'الفروع',   fn: () => go('/branches') },
        isWorkshop &&
          { id: 'go:reports',     label: 'التقارير', fn: () => go('/reports') },
        isWorkshop &&
          { id: 'go:technicians', label: 'الفنيون',  fn: () => go('/technicians') },
        isWorkshop &&
          { id: 'go:inventory',   label: 'المخزون',  fn: () => go('/inventory') },
        isWorkshop &&
          { id: 'go:services',    label: 'الخدمات',  fn: () => go('/services') },
      ].filter(Boolean) },

      { group: 'إجراءات', items: [
        { id: 'act:print', label: 'طباعة الملصق…',   fn: () => {/* hook into your print flow */} },
        { id: 'act:export', label: 'تصدير CSV',      fn: () => {/* optional */} },
      ] },

      { group: 'الطلبات', items: orders.slice(0, 8).map((o) => ({
        id: 'ord:' + o.id,
        label: `${o.order_number} — ${o.customer_name}`,
        hint:  o.piece_type,
        fn:    () => go(`/?order=${o.id}`),  // adapt to however you open detail
      })) },
    ];
  }, [orders, role]);

  const flat = commands.flatMap((g) => g.items.map((it) => ({ ...it, group: g.group })));
  const filtered = q
    ? flat.filter((it) => it.label.toLowerCase().includes(q.toLowerCase()))
    : flat;

  const groups = filtered.reduce((acc, it) => {
    (acc[it.group] = acc[it.group] || []).push(it);
    return acc;
  }, {});

  useEffect(() => {
    if (open) { inputRef.current?.focus(); setQ(''); setFocus(0); }
  }, [open]);
  useEffect(() => { setFocus(0); }, [q]);

  function onKey(e) {
    if (e.key === 'ArrowDown') { e.preventDefault(); setFocus((f) => Math.min(filtered.length - 1, f + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setFocus((f) => Math.max(0, f - 1)); }
    else if (e.key === 'Enter')   { e.preventDefault(); filtered[focus]?.fn(); }
    else if (e.key === 'Escape')  { onClose(); }
  }

  if (!open) return null;

  let idx = -1;
  return (
    <div
      className="fixed inset-0 z-[300] bg-black/30 backdrop-blur-sm flex items-start justify-center pt-[15vh]"
      onClick={onClose}
    >
      <div
        className="w-[90vw] max-w-[560px] bg-bg-raised border border-border rounded-lg shadow-lg overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <input
          ref={inputRef}
          className="w-full px-4 py-3.5 text-[15px] border-0 border-b border-border outline-none bg-transparent"
          placeholder="اكتب للبحث أو التنقل…"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onKeyDown={onKey}
        />
        <div className="max-h-[55vh] overflow-y-auto">
          {Object.keys(groups).length === 0 && (
            <div className="px-4 py-5 text-center text-sm text-text-muted">لا توجد نتائج</div>
          )}
          {Object.entries(groups).map(([g, items]) => (
            <div key={g}>
              <div className="px-4 pt-2.5 pb-1 text-[10px] uppercase tracking-wider text-text-faint">{g}</div>
              {items.map((it) => {
                idx += 1;
                const isFocus = idx === focus;
                return (
                  <div
                    key={it.id}
                    className={`flex items-center gap-3 px-4 py-2.5 cursor-pointer text-sm
                      ${isFocus ? 'bg-primary-soft text-primary' : 'text-text'}`}
                    onClick={it.fn}
                    onMouseEnter={() => setFocus(flat.findIndex((x) => x.id === it.id))}
                  >
                    <span className="flex-1 truncate">{it.label}</span>
                    {it.hint && (
                      <kbd className="text-[10px] font-mono px-1.5 py-0.5 bg-bg-soft border border-border rounded">
                        {it.hint}
                      </kbd>
                    )}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
        <div className="flex gap-3 px-4 py-2 border-t border-border text-[11px] text-text-faint">
          <span>↑↓ تنقل</span>
          <span>↵ اختيار</span>
          <span>esc إغلاق</span>
        </div>
      </div>
    </div>
  );
}
```

## Step 2 — Mount in `Layout.jsx`

Open `client/src/components/Layout.jsx`. Add at the top:

```jsx
import { useEffect, useState } from 'react';
import CommandPalette from './CommandPalette';
```

Inside the `Layout` function body, before the `return`:

```jsx
const [paletteOpen, setPaletteOpen] = useState(false);
const [orders, setOrders] = useState([]);

// Lightweight load for palette search. Don't block render on it.
useEffect(() => {
  let cancelled = false;
  import('../api/orders')
    .then((m) => (m.listOrders || m.getOrders || m.default)?.())
    .then((data) => !cancelled && setOrders(data || []))
    .catch(() => {});
  return () => { cancelled = true; };
}, []);

useEffect(() => {
  const onKey = (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      setPaletteOpen((v) => !v);
    }
  };
  window.addEventListener('keydown', onKey);
  return () => window.removeEventListener('keydown', onKey);
}, []);
```

At the end of the Layout JSX (inside the root `<div>`, after children):

```jsx
<CommandPalette
  open={paletteOpen}
  onClose={() => setPaletteOpen(false)}
  orders={orders}
/>
```

> **Important:** check what your `api/orders.js` actually exports. The dynamic import above tries `listOrders`, `getOrders`, and `default` in that order. Update if your export name is different (e.g. `fetchOrders`).

## Step 3 — Add a visible ⌘K hint

In the sidebar header or topbar, add a small button so users discover the palette. Example — add this above the nav in `Layout.jsx`:

```jsx
<button
  onClick={() => setPaletteOpen(true)}
  className="mx-4 mb-3 flex items-center justify-between gap-2 px-3 py-2 text-sm text-text-muted bg-bg-soft border border-border rounded hover:border-primary hover:text-primary transition-colors"
>
  <span>بحث سريع…</span>
  <kbd className="font-mono text-[10px] px-1.5 py-0.5 bg-bg-raised border border-border rounded">⌘K</kbd>
</button>
```

## Step 4 — Verify

```bash
cd client && npm run dev
```

Checks:
- [ ] Press **Cmd+K** (Mac) or **Ctrl+K** (Windows) from any page → palette opens, input focused
- [ ] Type "مسح" → "مسح" highlights in the "انتقال" group
- [ ] Press **Enter** → navigates to `/scan`
- [ ] Press **Esc** → palette closes
- [ ] Arrow up/down moves the selection highlight
- [ ] Mouse hover also moves the highlight
- [ ] Click outside the palette closes it
- [ ] Type an order number prefix like "WB-20" → matching orders appear
- [ ] Role-gated items: workshop account sees branches/reports/etc.; shop account sees "صيانة جديدة"
- [ ] Sidebar "بحث سريع" button opens the palette too
- [ ] `npm run build` passes

## Step 5 — Commit

```bash
git add client/src/components/CommandPalette.jsx client/src/components/Layout.jsx
git commit -m "feat: ⌘K command palette with role-gated nav + order search (Phase 3.1)"
```

---

## Gotchas

- **Dynamic import of `api/orders.js`** — if the module throws, the palette just gets an empty orders list (still works for nav). If you'd rather block, use a normal static import.
- **RTL cursor in the input:** Arabic placeholder renders correctly because the whole app is `dir="rtl"`. The `kbd` hint on the right of each item stays visually where expected.
- **If you have a global search input in the topbar already:** bind it to open the palette with the query pre-filled. The palette can accept an initial query via an extra prop — trivial addition.
- **Performance:** the orders list is filtered client-side with `String.includes`. Fine up to a few thousand orders. Beyond that, call a server-side search endpoint on-change (debounce 150ms).
