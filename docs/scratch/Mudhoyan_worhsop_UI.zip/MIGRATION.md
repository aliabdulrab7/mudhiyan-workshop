# Migration Plan — Workbench Prototype → Your Real Codebase

Your real app at `client/` is already close in spirit (same RTL, same palette, same pages). This migration is about **lifting the refined visual system and the new features** into your codebase without breaking what works.

Do it in **4 phases** — each one ships safely on its own.

---

## Phase 1 — Design tokens + type (30–45 min, zero risk)

**Goal:** adopt the denser token system. Nothing visual changes dramatically yet, but every screen gets tighter.

### 1.1 Replace `client/src/index.css` token block

Swap the `:root {…}` block (lines ~6–56) with the tokens from the prototype. Key changes:

```css
:root {
  /* Surfaces */
  --bg:          #F7F8FA;     /* was #F3F4F6 — slightly warmer */
  --bg-soft:     #F2F3F6;
  --bg-raised:   #FFFFFF;
  --bg-sidebar:  #FBFBFC;

  /* Border system — 3 levels, not 1 */
  --border:        #EAECEF;
  --border-strong: #D7DBE0;
  --border-faint:  #F0F1F3;

  /* Text — 4 levels */
  --text:        #1A1D21;
  --text-muted:  #6B7280;
  --text-faint:  #9AA0A6;
  --text-soft:   #4B5563;

  /* Primary stays teal — just add ring + hover states */
  --primary:       #2980B9;
  --primary-hover: #1A6EA0;
  --primary-soft:  rgba(41,128,185,0.08);
  --primary-ring:  rgba(41,128,185,0.18);

  /* Status — semantic, used by StatusBadge */
  --status-received-bg:  #EFF6FF;  --status-received-fg:  #2980B9;
  --status-inspect-bg:   #FEF3C7;  --status-inspect-fg:   #92400E;
  --status-waiting-bg:   #FEF3C7;  --status-waiting-fg:   #B45309;
  --status-repair-bg:    #DBEAFE;  --status-repair-fg:    #1E40AF;
  --status-quality-bg:   #F3E8FF;  --status-quality-fg:   #6B21A8;
  --status-ready-bg:     #DCFCE7;  --status-ready-fg:     #166534;
  --status-delivered-bg: #E5E7EB;  --status-delivered-fg: #374151;

  /* Radii */
  --radius-sm: 4px;
  --radius:    6px;     /* was 8 — tighter */
  --radius-md: 8px;
  --radius-lg: 10px;

  /* Shadows — more subtle */
  --shadow-sm: 0 1px 2px rgba(10,12,15,0.04);
  --shadow-md: 0 2px 6px rgba(10,12,15,0.06), 0 1px 2px rgba(10,12,15,0.04);
  --shadow-lg: 0 8px 24px rgba(10,12,15,0.08);
}
```

### 1.2 Add mono-numeric font stack

In `client/index.html`, add to the Google Fonts preload:

```html
<link href="https://fonts.googleapis.com/css2?family=Almarai:wght@400;700&family=JetBrains+Mono:wght@400;500&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
```

Then in `index.css`, add a helper:

```css
.mono { font-family: 'JetBrains Mono', ui-monospace, monospace; font-variant-numeric: tabular-nums; }
body { font-family: 'Almarai', 'Inter', sans-serif; }
```

All order numbers, prices, counts, and dates should use `.mono` going forward. This is the single biggest readability win.

### 1.3 Update `tailwind.config.js`

```js
colors: {
  bg:      { DEFAULT: '#F7F8FA', soft: '#F2F3F6', raised: '#FFFFFF' },
  border:  { DEFAULT: '#EAECEF', strong: '#D7DBE0', faint: '#F0F1F3' },
  text:    { DEFAULT: '#1A1D21', muted: '#6B7280', faint: '#9AA0A6' },
  primary: { DEFAULT: '#2980B9', hover: '#1A6EA0', soft: 'rgba(41,128,185,0.08)' },
},
```

**Test:** `npm run dev` — app should look almost identical, slightly tighter. Commit here.

---

## Phase 2 — Shared primitives (1–2 hrs)

Create three new files in `client/src/components/`. These replace ad-hoc styling across pages.

### 2.1 `components/StatusPill.jsx` (replaces `StatusBadge.jsx`)

A single component that maps any `status` string to a colored pill using the `--status-*-bg/fg` tokens. Port from `src/primitives.jsx` → `StatusPill` in this project. Find/replace `<StatusBadge>` usages across pages.

### 2.2 `components/Button.jsx`

Three variants: `primary`, `ghost`, `subtle`. Three sizes: `sm`, `md`, `lg`. Port from the `.btn .btn-primary .btn-lg` CSS classes in `styles.css`. Replace your current `.btn-gold / .btn-ghost / .btn-primary` CSS classes with this component.

### 2.3 `components/DataTable.jsx`

The dense orders-table pattern from `src/page_orders.jsx` — tight row height (40px), zebra optional, column alignment, hover state with right-border accent, bulk-select checkbox column. This is a huge upgrade over the current `OrderList.jsx`.

**Rule:** after this phase, no page should define its own button, badge, or table styles.

---

## Phase 3 — Port the new features (2–3 hrs)

These are the interaction upgrades from the prototype. Add them one at a time.

### 3.1 Command Palette (⌘K) — HIGH VALUE

Port `src/palette.jsx` as `client/src/components/CommandPalette.jsx`.

Mount it once in `Layout.jsx`. Wire the commands:
- "Go to Dashboard" → `navigate('/')`
- "New intake" → `navigate('/new')`
- "Scan order" → `navigate('/scan')`
- "Search order WB-…" → fuzzy match against loaded orders, jump to detail
- "Change theme / language" → toggle

Keyboard: `⌘K` / `Ctrl+K` opens, `Esc` closes, arrows navigate, Enter executes.

This alone will make your team 2× faster. Start here if you want the highest-impact single change.

### 3.2 Refined Track page

Replace the current `pages/TrackPage.jsx` with the layout from `src/page_track.jsx`:
- Centered single-card layout
- 6-stage horizontal timeline with numbered dots, done/current/future states
- RTL-aware labels ("بدأ" on start side, "Ready for pickup" on end side)
- Two info tiles (drop-off location, estimated total)
- Two CTAs (contact branch, approve quote)
- Auto-updates tagline

Your current Track page is reportedly simpler — this version is the customer-facing page that should feel polished.

### 3.3 Dashboard redesign

Port `src/page_dashboard.jsx` patterns into `pages/Dashboard.jsx`:
- **Stats row** at top: 4–5 numeric cards (received today, in repair, waiting approval, ready for pickup, overdue). Each card: label, big mono number, trend line below.
- **"Needs your attention"** list — orders flagged by overdue / pending customer approval / out-of-stock parts.
- **Recent activity** feed on the right.
- Ditch any decorative hero art; make it informational.

### 3.4 New Order intake — multi-step form

Your current `NewOrder.jsx` is one big form. Port the stepper pattern from `src/page_new.jsx`:
1. Customer (search existing / create new)
2. Pieces & issues (add multiple)
3. Services & pricing (auto-totaled)
4. Review

Keyboard: Tab flows through, Enter advances, Cmd+Enter submits from any step.

### 3.5 Toast system

Port `components/Toast.jsx` if you haven't already — top-center, auto-dismiss, used by save/approve/print actions.

---

## Phase 4 — Polish pass (1 hr)

Go through every page and apply:

1. **Tabular numerals everywhere** — any number, price, date, ID, count gets `.mono` class.
2. **Tighten spacing** — default gap is 12px, not 16. Cards get 16px padding, not 24.
3. **Status pill, never text** — no raw `{order.status}` anywhere; always `<StatusPill status={order.status} />`.
4. **Remove decorative gradients** — replace `linear-gradient(135deg, …)` sidebar logo with a flat square.
5. **Consistent empty states** — small illustration, one-line description, one CTA button.

---

## What to NOT migrate

- The Tweaks panel (that's a prototype-only thing)
- The "Export / Refresh" mock buttons (you have real equivalents)
- Hard-coded mock data in `data.jsx` (you have a real API)
- The bilingual toggle implementation (yours is already RTL-first; don't rewrite)

---

## Quick start — today

If you only have 1 hour today, do **Phase 1** (tokens + mono font). Every screen in your app will immediately feel more considered, and nothing will break.

If you have a full afternoon, do **Phase 1 + 3.1 (Command Palette)**. ⌘K is the single feature most likely to get your team hooked on the new version.

---

## Files to copy as reference

From this prototype → into your codebase as `client/src/_reference/`:
- `src/primitives.jsx` — button, pill, input, card components
- `src/palette.jsx` — command palette full implementation
- `src/page_track.jsx` — track page layout
- `src/page_dashboard.jsx` — dashboard patterns
- `styles.css` — the design tokens (lines 1–200)

Keep them in a `_reference/` folder so you can grep into them while porting. Delete the folder when done.
